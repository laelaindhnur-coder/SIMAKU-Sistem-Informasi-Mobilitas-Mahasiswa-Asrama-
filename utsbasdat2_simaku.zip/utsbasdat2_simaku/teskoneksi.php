<?php
require_once "koneksi.php";

echo "<h2>Koneksi Database SIMAKU Berhasil!</h2>";

$result = $conn->query("SELECT DATABASE() AS nama_database");
$data = $result->fetch_assoc();

echo "Database aktif: " . htmlspecialchars($data['nama_database']);
?>