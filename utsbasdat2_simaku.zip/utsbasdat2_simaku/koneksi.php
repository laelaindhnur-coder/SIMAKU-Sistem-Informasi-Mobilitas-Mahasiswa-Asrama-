<?php
// ========================================
// KONEKSI DATABASE SIMAKU
// ========================================
$host = "localhost";
$username = "root";
$password = "";
$database = "utsbasdat2_simaku";

// Membuat koneksi ke database
$conn = new mysqli($host, $username, $password, $database);

// Memeriksa koneksi
if ($conn->connect_error) {
    die("<h3>Koneksi Database Gagal!</h3><p>" . htmlspecialchars($conn->connect_error) . "</p>");
}

// Mengatur karakter database
$conn->set_charset("utf8mb4");

// ========================================
// FUNGSI HELPER AMBIL & HITUNG DATA
// ========================================
function ambilData($conn, $sql) {
    $result = $conn->query($sql);
    if (!$result) {
        die("Query gagal: " . htmlspecialchars($conn->error));
    }
    return $result;
}

function hitungData($conn, $sql) {
    $result = $conn->query($sql);
    if (!$result) {
        return 0;
    }
    $data = $result->fetch_row();
    return (int) ($data[0] ?? 0);
}
?>
