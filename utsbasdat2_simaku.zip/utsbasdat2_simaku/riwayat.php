<?php
require_once "koneksi.php";

// QUERY RIWAYAT TRANSAKSI DARI DATABASE
$sql = "
    SELECT 
        tm.id_transaksi,
        m.nim,
        m.nama_mahasiswa,
        i.tujuan,
        i.waktu_mulai,
        i.batas_kembali,
        tm.waktu_keluar,
        tm.waktu_masuk,
        tm.status_transaksi,
        tm.status_keterlambatan
    FROM transaksi_keluar_masuk tm
    INNER JOIN izin i ON tm.id_izin = i.id_izin
    INNER JOIN mahasiswa m ON i.id_mahasiswa = m.id_mahasiswa
    ORDER BY tm.id_transaksi DESC
";
$result = $conn->query($sql);

function e($value) {
    return htmlspecialchars((string) ($value ?? '-'), ENT_QUOTES, 'UTF-8');
}

function formatWaktu($waktu) {
    if (empty($waktu)) {
        return '-';
    }
    $ts = strtotime($waktu);
    return $ts ? date('d-m-Y H:i', $ts) : e($waktu);
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Riwayat Transaksi | SIMAKU</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <style>
        :root {
            --yellow: #facc15; --background: #0b0b0b; --card: #171717;
            --border: #303030; --text: #f5f5f5; --muted: #a3a3a3;
            --green: #48D597; --red: #FF5252;
        }
        * { box-sizing: border-box; }
        body { margin: 0; padding: 30px; background: var(--background); color: var(--text); font-family: 'Space Grotesk', sans-serif; }
        .container { max-width: 1400px; margin: auto; }
        .header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px; }
        h1 { margin: 0; color: var(--yellow); font-size: 28px; }
        .button { display: inline-block; padding: 10px 16px; border-radius: 7px; background: var(--yellow); color: #111; text-decoration: none; font-weight: bold; }
        .table-panel { background: var(--card); border: 1px solid var(--border); border-radius: 10px; overflow: hidden; }
        table { width: 100%; border-collapse: collapse; text-align: left; }
        th { padding: 14px 18px; background: #202020; color: var(--muted); font-size: 11px; border-bottom: 1px solid var(--border); }
        td { padding: 16px 18px; border-bottom: 1px solid #282828; font-size: 13px; }
        .badge { display: inline-block; padding: 4px 8px; border-radius: 4px; font-size: 11px; font-weight: bold; }
        .badge-success { background: #103326; color: var(--green); }
        .badge-danger { background: #3B1C1C; color: var(--red); }
        .badge-warning { background: #302A0A; color: var(--yellow); }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <div>
                <h1>Riwayat Keluar Masuk</h1>
                <p style="color: var(--muted); margin-top: 5px;">Rekapitulasi lengkap data transaksi mahasiswi asrama.</p>
            </div>
            <a href="index.php" class="button"><i class="fa-solid fa-house"></i> Ke Dashboard</a>
        </div>

        <div class="table-panel">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>NIM</th>
                        <th>NAMA MAHASISWI</th>
                        <th>TUJUAN</th>
                        <th>WAKTU KELUAR</th>
                        <th>BATAS KEMBALI</th>
                        <th>WAKTU MASUK</th>
                        <th>STATUS TRANSAKSI</th>
                        <th>KETERLAMBATAN</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($result && $result->num_rows > 0): ?>
                        <?php while ($row = $result->fetch_assoc()): ?>
                            <tr>
                                <td>#<?= e($row['id_transaksi']) ?></td>
                                <td><?= e($row['nim']) ?></td>
                                <td><strong><?= e($row['nama_mahasiswa']) ?></strong></td>
                                <td><?= e($row['tujuan']) ?></td>
                                <td><?= formatWaktu($row['waktu_keluar']) ?></td>
                                <td><?= formatWaktu($row['batas_kembali']) ?></td>
                                <td><?= formatWaktu($row['waktu_masuk']) ?></td>
                                <td>
                                    <?php if ($row['status_transaksi'] === 'Sedang di luar'): ?>
                                        <span class="badge badge-warning">Sedang di Luar</span>
                                    <?php else: ?>
                                        <span class="badge badge-success">Selesai</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if ($row['status_keterlambatan'] === 'Terlambat'): ?>
                                        <span class="badge badge-danger">Terlambat</span>
                                    <?php elseif ($row['status_keterlambatan'] === 'Tepat Waktu'): ?>
                                        <span class="badge badge-success">Tepat Waktu</span>
                                    <?php else: ?>
                                        <span class="badge badge-warning">Belum Kembali</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="9" style="text-align: center; color: var(--muted); padding: 30px;">
                                Belum ada riwayat transaksi yang terekam.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>
