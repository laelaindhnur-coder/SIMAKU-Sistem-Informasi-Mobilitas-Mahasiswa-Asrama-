<?php
require_once "koneksi.php";

$pesan = "";
$tipePesan = "";

// 1. PROSES INPUT IZIN KELUAR BARU (Menggunakan Stored Procedure sp_catat_keluar)
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["catat_keluar"])) {
    $id_mahasiswa = (int)$_POST["id_mahasiswa"];
    $tujuan = trim($_POST["tujuan"]);
    $batas_kembali = $_POST["batas_kembali"];

    if (!empty($id_mahasiswa) && !empty($tujuan) && !empty($batas_kembali)) {
        // Panggil Stored Procedure sp_catat_keluar
        $stmt = $conn->prepare("CALL sp_catat_keluar(?, ?, ?)");
        $stmt->bind_param("iss", $id_mahasiswa, $tujuan, $batas_kembali);

        if ($stmt->execute()) {
            $pesan = "Berhasil mencatat mahasiswi keluar asrama!";
            $tipePesan = "success";
        } else {
            $pesan = "Gagal memproses transaksi: " . $conn->error;
            $tipePesan = "error";
        }
        $stmt->close();
    } else {
        $pesan = "Harap pilih mahasiswi dan lengkapi semua form inputan!";
        $tipePesan = "error";
    }
}

// 2. PROSES KONFIRMASI KEMBALI (Memicu Trigger MySQL 'before_update_transaksi_kembali')
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["konfirmasi_kembali"])) {
    $id_transaksi = (int)$_POST["id_transaksi"];

    if ($id_transaksi > 0) {
        // Update waktu_masuk saja, Trigger di database otomatis menghitung keterlambatan
        $stmt = $conn->prepare("UPDATE transaksi_keluar_masuk SET waktu_masuk = NOW() WHERE id_transaksi = ?");
        $stmt->bind_param("i", $id_transaksi);

        if ($stmt->execute()) {
            $pesan = "Pencatatan kepulangan berhasil diperbarui!";
            $tipePesan = "success";
        } else {
            $pesan = "Gagal memperbarui kepulangan: " . $conn->error;
            $tipePesan = "error";
        }
        $stmt->close();
    }
}

// AMBIL DAFTAR MAHASISWA DARI DATABASE (untuk autocomplete & pencarian)
$listMahasiswa = $conn->query("SELECT id_mahasiswa, nim, nama_mahasiswa FROM mahasiswa ORDER BY nama_mahasiswa ASC");
$arrMahasiswa = [];
while ($m = $listMahasiswa->fetch_assoc()) {
    $arrMahasiswa[] = $m;
}

// AMBIL DAFTAR MAHASISWA YANG SEDANG DI LUAR
$listDiLuar = $conn->query("
    SELECT tm.id_transaksi, m.nama_mahasiswa, m.nim, i.tujuan, i.batas_kembali
    FROM transaksi_keluar_masuk tm
    JOIN izin i ON tm.id_izin = i.id_izin
    JOIN mahasiswa m ON i.id_mahasiswa = m.id_mahasiswa
    WHERE tm.status_transaksi = 'Sedang di luar'
    ORDER BY tm.waktu_keluar DESC
");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SIMAKU | Input KTM</title>
    <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <style>
        :root { 
            --yellow: #FFD600; 
            --yellow-hover: #FFE44D;
            --background: #101010; 
            --card: #191919; 
            --border: #303030; 
            --white: #F5F5F5; 
            --muted: #A3A3A3; 
        }
        * { box-sizing: border-box; }
        body { 
            font-family: 'Space Grotesk', sans-serif; 
            background: var(--background); 
            color: var(--white); 
            margin: 0; 
            padding: 20px 5%; 
        }
        .container { max-width: 1200px; margin: 0 auto; }
        .alert { padding: 12px 18px; border-radius: 8px; margin-bottom: 20px; font-weight: 600; }
        .alert-success { background: #103326; color: #48D597; border: 1px solid #48D597; }
        .alert-error { background: #3B1C1C; color: #FF5252; border: 1px solid #FF5252; }
        .grid-form { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
        .card { background: var(--card); border: 1px solid var(--border); padding: 25px; border-radius: 12px; }
        h2 { color: var(--yellow); margin-top: 0; font-size: 20px; }
        .form-group { margin-bottom: 15px; }
        label { display: block; margin-bottom: 6px; font-size: 12px; color: var(--muted); }
        .required { color: var(--yellow); }
        select, input, textarea { 
            width: 100%; 
            padding: 12px; 
            background: #222; 
            border: 1px solid var(--border); 
            color: #fff; 
            border-radius: 6px; 
            font-family: inherit;
        }
        select:focus, input:focus, textarea:focus { border-color: var(--yellow); outline: none; }
        textarea { resize: vertical; min-height: 80px; }
        .btn { 
            padding: 12px 20px; 
            background: var(--yellow); 
            color: #000; 
            font-weight: 700; 
            border: none; 
            border-radius: 6px; 
            cursor: pointer; 
            width: 100%; 
            margin-top: 10px; 
            transition: 0.2s;
        }
        .btn:hover { background: var(--yellow-hover); }
        .btn-green { background: #48D597; }
        .btn-green:hover { background: #3cc286; }
        a.back-link { display: inline-block; color: var(--yellow); margin-bottom: 20px; text-decoration: none; font-weight: 600; }
        @media (max-width: 768px) {
            .grid-form { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>
    <div class="container">
        <a href="index.php" class="back-link"><i class="fa-solid fa-arrow-left"></i> Kembali ke Dashboard</a>
        <h1 style="margin-bottom: 25px;">Pencatatan Keluar & Masuk Mahasiswi</h1>

        <?php if (!empty($pesan)): ?>
            <div class="alert alert-<?= $tipePesan ?>"><?= htmlspecialchars($pesan) ?></div>
        <?php endif; ?>

        <div class="grid-form">
            <!-- FORM 1: CATAT KELUAR -->
            <div class="card">
                <h2><i class="fa-solid fa-arrow-right-from-bracket"></i> Form Keberangkatan</h2>
                <form action="input.php" method="POST">
                    <!-- Hidden ID Mahasiswa yang akan diisi otomatis lewat Datalist/Search -->
                    <input type="hidden" id="id_mahasiswa" name="id_mahasiswa">

                    <!-- Input Pencarian/Ketik Nama atau NIM -->
                    <div class="form-group">
                        <label for="search-student">Cari / Ketik Nama / NIM Mahasiswi <span class="required">*</span></label>
                        <input type="text" id="search-student" list="student-list-options" class="form-control" placeholder="Ketik nama atau NIM mahasiswi..." autocomplete="off" required>
                        <datalist id="student-list-options">
                            <?php foreach ($arrMahasiswa as $mhs): ?>
                                <option value="<?= htmlspecialchars($mhs['nama_mahasiswa']) ?> (NIM: <?= htmlspecialchars($mhs['nim']) ?>)" data-id="<?= $mhs['id_mahasiswa'] ?>"></option>
                            <?php endforeach; ?>
                        </datalist>
                    </div>

                    <div class="form-group">
                        <label for="tujuan">Tujuan Keluar <span class="required">*</span></label>
                        <textarea id="tujuan" name="tujuan" class="form-control" placeholder="Contoh: Membeli kebutuhan di La Tansa Mart" required></textarea>
                    </div>
                    
                    <div class="form-group">
                        <label for="tenggat">Tenggat Waktu Kembali <span class="required">*</span></label>
                        <input type="datetime-local" id="tenggat" name="batas_kembali" class="form-control" required>
                    </div>
                    
                    <button type="submit" name="catat_keluar" class="btn"><i class="fa-solid fa-check"></i> Konfirmasi Keluar</button>
                </form>
            </div>

            <!-- FORM 2: KONFIRMASI KEMBALI -->
            <div class="card">
                <h2><i class="fa-solid fa-house-user"></i> Konfirmasi Kepulangan</h2>
                <form action="input.php" method="POST">
                    <div class="form-group">
                        <label>Pilih Mahasiswi yang Kembali</label>
                        <select name="id_transaksi" required>
                            <option value="">-- Pilih Mahasiswi --</option>
                            <?php while ($d = $listDiLuar->fetch_assoc()): ?>
                                <option value="<?= $d['id_transaksi'] ?>" <?= (isset($_GET['id_transaksi']) && $_GET['id_transaksi'] == $d['id_transaksi']) ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($d['nama_mahasiswa']) ?> - [Batas: <?= date('d/m H:i', strtotime($d['batas_kembali'])) ?>]
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    <button type="submit" name="konfirmasi_kembali" class="btn btn-green"><i class="fa-solid fa-check"></i> Konfirmasi Sudah Kembali</button>
                </form>
            </div>
        </div>
    </div>

    <!-- JAVASCRIPT UNTUK PENCARIAN & AUTO-FILL ID MAHASISWA -->
    <script>
    const dataMahasiswa = <?= json_encode($arrMahasiswa) ?>;
    const searchInput = document.getElementById('search-student');
    const idHiddenInput = document.getElementById('id_mahasiswa');

    // Menghubungkan teks pilihan ke ID Mahasiswa di tabel MySQL
    searchInput.addEventListener('input', function() {
        const val = this.value;
        const found = dataMahasiswa.find(m => 
            val.includes(m.nama_mahasiswa) || val.includes(m.nim)
        );

        if (found) {
            idHiddenInput.value = found.id_mahasiswa;
        } else {
            idHiddenInput.value = '';
        }
    });

    // Mengeset minimal batas kembali adalah waktu saat ini
    const tenggatInput = document.getElementById('tenggat');
    if (tenggatInput) {
        const now = new Date();
        const offset = now.getTimezoneOffset() * 60000;
        const localISOTime = (new Date(now.getTime() - offset)).toISOString().slice(0, 16);
        tenggatInput.min = localISOTime;
    }
    </script>
</body>
</html>