<?php
require_once "koneksi.php";

// 1. HITUNG STATISTIK DINAMIS
$totalMahasiswa = hitungData($conn, "SELECT COUNT(*) FROM mahasiswa");
$totalLuar = hitungData($conn, "SELECT COUNT(*) FROM transaksi_keluar_masuk WHERE status_transaksi = 'Sedang di luar'");
$totalKembali = hitungData($conn, "SELECT COUNT(*) FROM transaksi_keluar_masuk WHERE status_transaksi = 'Selesai' AND DATE(waktu_masuk) = CURDATE()");
$totalKeluarHariIni = hitungData($conn, "SELECT COUNT(*) FROM transaksi_keluar_masuk WHERE DATE(waktu_keluar) = CURDATE()");
$totalTerlambat = hitungData($conn, "SELECT COUNT(*) FROM transaksi_keluar_masuk WHERE status_keterlambatan = 'Terlambat'");

// 2. QUERY DAFTAR MAHASISWI SEDANG DI LUAR
$queryDaftarLuar = "
    SELECT 
    m.nama_mahasiswa, 
        m.nim, 
        i.tujuan, 
        tm.waktu_keluar, 
        i.batas_kembali, 
        tm.status_keterlambatan, 
        tm.id_transaksi
    FROM transaksi_keluar_masuk tm
    JOIN izin i ON tm.id_izin = i.id_izin
    JOIN mahasiswa m ON i.id_mahasiswa = m.id_mahasiswa
    WHERE tm.status_transaksi = 'Sedang di luar'
    ORDER BY tm.waktu_keluar DESC
";
$resDaftarLuar = $conn->query($queryDaftarLuar);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SIMAKU | Dashboard Satpam</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <style>
        :root {
            --yellow: #FFD600;
            --yellow-hover: #FFE44D;
            --black: #090909;
            --background: #101010;
            --card: #191919;
            --card-hover: #222222;
            --border: #303030;
            --white: #F5F5F5;
            --muted: #A3A3A3;
            --red: #FF5252;
            --green: #48D597;
            --blue: #62A5FF;
        }
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Space Grotesk', sans-serif;
            background: var(--background);
            color: var(--white);
            min-height: 100vh;
        }
        a { color: inherit; text-decoration: none; }
        button { font-family: inherit; }

        /* NAVBAR */
        .navbar {
            position: sticky; top: 0; z-index: 100; width: 100%; min-height: 82px;
            padding: 14px 5%; display: flex; align-items: center; justify-content: space-between;
            gap: 25px; flex-wrap: wrap;
            background: linear-gradient(110deg, #080808 0%, #171717 60%, #262000 100%);
            border-bottom: 1px solid #373000; box-shadow: 0 5px 25px rgba(0, 0, 0, 0.3);
        }
        .brand { display: flex; align-items: center; gap: 13px; }
        .brand-logo { width: 48px; height: 55px; object-fit: contain; }
        .brand-name { color: var(--yellow); font-size: 24px; font-weight: 700; letter-spacing: 1.5px; }
        .brand-name span { color: white; }
        .brand-description { margin-top: 4px; color: var(--muted); font-size: 10px; letter-spacing: 0.3px; }
        .nav-menu { display: flex; align-items: center; gap: 8px; }
        .nav-link {
            display: flex; align-items: center; gap: 9px; padding: 12px 15px;
            border: 1px solid transparent; border-radius: 8px; color: #C3C3C3;
            font-size: 13px; font-weight: 600; transition: all 0.2s ease;
        }
        .nav-link:hover { color: var(--yellow); background: #24210E; }
        .nav-link.active { color: var(--black); background: var(--yellow); border-color: var(--yellow); }

        /* LAYOUT CONTAINER */
        .container { width: 100%; max-width: 1500px; margin: 0 auto; padding: 38px 5%; }
        .page-heading { display: flex; justify-content: space-between; align-items: center; gap: 20px; margin-bottom: 30px; }
        .eyebrow { display: inline-flex; align-items: center; gap: 8px; color: var(--yellow); font-size: 11px; font-weight: 700; letter-spacing: 1.5px; margin-bottom: 12px; }
        .eyebrow-dot { width: 7px; height: 7px; border-radius: 50%; background: var(--yellow); box-shadow: 0 0 10px rgba(255, 214, 0, 0.7); }
        .page-heading h1 { font-size: clamp(25px, 3vw, 35px); font-weight: 700; letter-spacing: -1.2px; line-height: 1.2; }
        .page-heading p { margin-top: 10px; color: var(--muted); font-size: 13px; line-height: 1.7; }
        .heading-actions { display: flex; align-items: center; gap: 10px; flex-shrink: 0; }
        
        .btn {
            display: inline-flex; align-items: center; justify-content: center; gap: 9px;
            padding: 13px 17px; border-radius: 8px; border: 1px solid var(--border);
            font-size: 13px; font-weight: 700; cursor: pointer; transition: all 0.2s ease;
        }
        .btn-primary { background: linear-gradient(110deg, #FFD600, #F3C900); color: #111111; border-color: var(--yellow); }
        .btn-primary:hover { background: var(--yellow-hover); transform: translateY(-2px); }
        .btn-secondary { background: var(--card); color: var(--white); }
        .btn-secondary:hover { border-color: var(--yellow); color: var(--yellow); }

        /* STATS GRID */
        .stats-grid { display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 18px; margin-bottom: 28px; }
        .stat-card {
            position: relative; overflow: hidden; padding: 23px; min-height: 185px;
            background: linear-gradient(145deg, #202020, #151515); border: 1px solid var(--border);
            border-radius: 12px; transition: all 0.25s ease;
        }
        .stat-card:hover { transform: translateY(-4px); border-color: #716000; background: var(--card-hover); }
        .stat-card::after { content: ""; position: absolute; bottom: 0; left: 0; width: 100%; height: 3px; background: var(--yellow); }
        .stat-top { display: flex; align-items: center; justify-content: space-between; gap: 12px; }
        .stat-label { color: #D4D4D4; font-size: 11px; font-weight: 700; letter-spacing: 0.5px; }
        .stat-icon { width: 39px; height: 39px; display: flex; align-items: center; justify-content: center; border-radius: 10px; background: #332D00; color: var(--yellow); font-size: 16px; }
        .stat-number { margin-top: 23px; font-size: 39px; font-weight: 700; line-height: 1; color: var(--white); }
        .stat-description { margin-top: 11px; color: var(--muted); font-size: 11px; line-height: 1.6; }

        .stat-card.green::after { background: var(--green); }
        .stat-card.green .stat-icon { color: var(--green); background: #103326; }
        .stat-card.blue::after { background: var(--blue); }
        .stat-card.blue .stat-icon { color: var(--blue); background: #172B43; }
        .stat-card.red::after { background: var(--red); }
        .stat-card.red .stat-icon { color: var(--red); background: #3B1C1C; }

        /* TABLE STYLING */
        .table-panel { background: var(--card); border: 1px solid var(--border); border-radius: 12px; overflow: hidden; }
        .panel-header { display: flex; justify-content: space-between; align-items: center; gap: 15px; padding: 23px 25px; border-bottom: 1px solid var(--border); }
        .panel-title { display: flex; align-items: center; gap: 10px; font-size: 18px; font-weight: 700; }
        .panel-title i { color: var(--yellow); }
        .panel-subtitle { margin-top: 7px; color: var(--muted); font-size: 12px; }
        .count-badge { padding: 8px 12px; border-radius: 7px; background: #29250E; color: var(--yellow); font-size: 11px; font-weight: 700; }
        .table-wrapper { width: 100%; overflow-x: auto; }
        table { width: 100%; border-collapse: collapse; white-space: nowrap; }
        thead { background: #202020; }
        th { padding: 16px 20px; text-align: left; color: #C5C5C5; font-size: 10px; font-weight: 700; border-bottom: 1px solid var(--border); }
        td { padding: 18px 20px; border-bottom: 1px solid #2B2B2B; font-size: 12px; color: #D8D8D8; }
        tbody tr:hover { background: #222222; }
        .student-name { color: var(--white); font-weight: 700; font-size: 13px; }
        .mono { font-family: Consolas, monospace; font-size: 12px; }
        .status { display: inline-flex; align-items: center; gap: 7px; padding: 7px 10px; border-radius: 6px; font-size: 10px; font-weight: 700; }
        .status::before { content: ""; width: 6px; height: 6px; border-radius: 50%; background: currentColor; }
        .status-out { color: var(--yellow); background: #302A0A; }
        .empty-state { padding: 45px 20px; text-align: center; color: var(--muted); }
        .empty-state i { font-size: 30px; color: #696969; margin-bottom: 14px; }
        .table-footer { display: flex; justify-content: space-between; padding: 15px 22px; border-top: 1px solid var(--border); color: var(--muted); background: #151515; font-size: 11px; }
        .footer { max-width: 1500px; margin: 0 auto; padding: 15px 5% 25px; display: flex; justify-content: space-between; color: #777777; font-size: 11px; }
        .footer strong { color: var(--yellow); }
    </style>
</head>
<body>
    <header class="navbar">
        <a href="index.php" class="brand">
            <img src="images\logo unida.png" alt="Logo UNIDA" class="brand-logo">
            <div>
                <div class="brand-name">SIMAKU<span>.</span></div>
                <div class="brand-description">SISTEM INFORMASI MOBILITAS MAHASISWI ASRAMA</div>
            </div>
        </a>
        <nav class="nav-menu">
            <a href="index.php" class="nav-link active"><i class="fa-solid fa-chart-pie"></i> Dashboard</a>
            <a href="input.php" class="nav-link"><i class="fa-solid fa-barcode"></i>  Input KTM</a>
            <a href="riwayat.php" class="nav-link"><i class="fa-solid fa-clock-rotate-left"></i> Riwayat Transaksi</a>
        </nav>
    </header>

    <main class="container">
        <section class="page-heading">
            <div>
                <div class="eyebrow"><span class="eyebrow-dot"></span> SISTEM OPERASIONAL SATPAM</div>
                <h1>Dashboard Operasional</h1>
                <p>Pantau aktivitas keluar-masuk mahasiswi asrama dalam satu sistem terintegrasi.</p>
            </div>
            <div class="heading-actions">
                <a href="input.php" class="btn btn-primary"><i class="fa-solid fa-barcode"></i> Input data KTM</a>
                <button type="button" class="btn btn-secondary" onclick="location.reload()"><i class="fa-solid fa-rotate-right"></i> Refresh</button>
            </div>
        </section>

        <!-- KARTU STATISTIK DENGAN DATA DARI MYSQL -->
        <section class="stats-grid">
            <article class="stat-card">
                <div class="stat-top">
                    <div class="stat-label">SEDANG DI LUAR</div>
                    <div class="stat-icon"><i class="fa-solid fa-person-walking-arrow-right"></i></div>
                </div>
                <div class="stat-number"><?= $totalLuar ?></div>
                <div class="stat-description">Mahasiswi belum kembali ke asrama.</div>
            </article>

            <article class="stat-card green">
                <div class="stat-top">
                    <div class="stat-label">SUDAH KEMBALI</div>
                    <div class="stat-icon"><i class="fa-solid fa-house-user"></i></div>
                </div>
                <div class="stat-number"><?= $totalKembali ?></div>
                <div class="stat-description">Mahasiswi yang telah kembali hari ini.</div>
            </article>

            <article class="stat-card blue">
                <div class="stat-top">
                    <div class="stat-label">TOTAL KELUAR HARI INI</div>
                    <div class="stat-icon"><i class="fa-solid fa-arrow-right-from-bracket"></i></div>
                </div>
                <div class="stat-number"><?= $totalKeluarHariIni ?></div>
                <div class="stat-description">Total pencatatan keberangkatan hari ini.</div>
            </article>

            <article class="stat-card red">
                <div class="stat-top">
                    <div class="stat-label">TERLAMBAT</div>
                    <div class="stat-icon"><i class="fa-solid fa-clock"></i></div>
                </div>
                <div class="stat-number"><?= $totalTerlambat ?></div>
                <div class="stat-description">Mahasiswi yang terlambat kembali.</div>
            </article>
        </section>

        <!-- TABEL DARI DATABASE -->
        <section class="table-panel">
            <div class="panel-header">
                <div>
                    <h2 class="panel-title"><i class="fa-solid fa-users"></i> Mahasiswi Sedang Berada di Luar</h2>
                    <p class="panel-subtitle">Daftar mahasiswi yang belum mencatatkan kepulangan.</p>
                </div>
                <div class="count-badge"><?= $totalLuar ?> MAHASISWI</div>
            </div>
            <div class="table-wrapper">
                <table>
                    <thead>
                        <tr>
                            <th>MAHASISWI</th>
                            <th>NIM</th>
                            <th>TUJUAN IZIN</th>
                            <th>WAKTU KELUAR</th>
                            <th>BATAS KEMBALI</th>
                            <th>STATUS</th>
                            <th>AKSI</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($resDaftarLuar && $resDaftarLuar->num_rows > 0): ?>
                            <?php while($row = $resDaftarLuar->fetch_assoc()): ?>
                                <tr>
                                    <td class="student-name"><?= htmlspecialchars($row['nama_mahasiswa']) ?></td>
                                    <td class="mono"><?= htmlspecialchars($row['nim']) ?></td>
                                    <td><?= htmlspecialchars($row['tujuan']) ?></td>
                                    <td><?= date('d/m/Y H:i', strtotime($row['waktu_keluar'])) ?></td>
                                    <td><?= date('d/m/Y H:i', strtotime($row['batas_kembali'])) ?></td>
                                    <td><span class="status status-out">Sedang di Luar</span></td>
                                    <td>
                                        <a href="input.php?id_transaksi=<?= $row['id_transaksi'] ?>" class="btn btn-primary" style="padding: 6px 12px; font-size:11px;">Konfirmasi Kembali</a>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="7">
                                    <div class="empty-state">
                                        <i class="fa-solid fa-database"></i>
                                        <strong>Belum ada mahasiswi yang sedang di luar</strong>
                                        <p style="margin-top:8px; font-size:12px;">Semua mahasiswi berada di dalam asrama.</p>
                                    </div>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <div class="table-footer">
                <span><i class="fa-solid fa-circle-info"></i> Dashboard SIMAKU</span>
                <span>Sistem Informasi Mobilitas dan Keluar-Masuk Mahasiswi Asrama</span>
            </div>
        </section>
    </main>

    <footer class="footer">
        <span><strong>SIMAKU</strong> © 2026</span>
        <span>Universitas Darussalam Gontor</span>
    </footer>
</body>
</html>
